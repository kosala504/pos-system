<?php
// module directory name
$HmvcConfig['bank']["_title"]     = "bank Details ";
$HmvcConfig['bank']["_description"] = "Simple bank processing System";
	  
$HmvcConfig['bank']['_database'] = true;
$HmvcConfig['bank']["_tables"] = array( 
	'bank_add',
	 
);
