<?php
// module directory name
$HmvcConfig['customer']["_title"]     = "customer Details ";
$HmvcConfig['customer']["_description"] = "Simple customer processing System";
	  
$HmvcConfig['customer']['_database'] = true;
$HmvcConfig['customer']["_tables"] = array( 
	'customer',
);
