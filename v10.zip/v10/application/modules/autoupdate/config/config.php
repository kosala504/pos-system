<?php
// module directory name
$HmvcConfig['autoupdate']["_title"]     = "autoupdate Details ";
$HmvcConfig['autoupdate']["_description"] = "Simple Autoupdate processing System";
	  
$HmvcConfig['bank']['_database'] = false;
$HmvcConfig['bank']["_tables"] = array( 
	
	 
);
