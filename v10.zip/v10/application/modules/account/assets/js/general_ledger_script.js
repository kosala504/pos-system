    $(document).ready(function(){
    	"use strict";
    
    });

     $(function(){
     	"use strict";
       
       
    });