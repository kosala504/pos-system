<?php
// module directory name
$HmvcConfig['invoice']["_title"]     = "invoice Details ";
$HmvcConfig['invoice']["_description"] = "Simple invoice processing System";
	  
	  
$HmvcConfig['invoice']['_database'] = true;
$HmvcConfig['invoice']["_tables"] = array( 
	'employee',
);